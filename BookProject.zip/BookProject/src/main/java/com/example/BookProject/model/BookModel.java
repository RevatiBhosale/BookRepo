package com.example.BookProject.model;

import com.example.BookProject.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;

public class BookModel {
    @Autowired
    BookRepository bookRepository;
}
