package com.example.BookProject.controller;

import com.example.BookProject.model.BookModel;
import com.example.BookProject.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

@RestController
public class BookController {

    private String gURL = "https://www.googleapis.com/books/v1/volumes";

    @Autowired
    BookModel BookModelObj;

    @Autowired
    com.example.BookProject.repository.BookRepository BookRepository;

    @RequestMapping("/get")
    public void getBook(@RequestParam String q) throws IOException, JSONException {

        gURL = gURL + "?" + URLEncoder.encode("q") + "=" + URLEncoder.encode(q) + URLEncoder.encode("maxResults") + "=" + URLEncoder.encode("1");
        URL url = new URL(gURL);
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        BufferedReader bufr = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
        StringBuffer response = new StringBuffer();
        String inputLine;
        while ((inputLine = bufr.readLine()) != null) {
            response.append(inputLine);
        }
        bufr.close();
        JSONObject result = new JSONObject(response.toString());
        System.out.println(result);
        JSONArray arr = (JSONArray) result.get("items");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.getJSONObject(i);
            System.out.println(obj);
            String kind = obj.get("kind").toString();
            String id = obj.get("id").toString();
            String tag = obj.get("etag").toString();
            String link = obj.get("selfLink").toString();
            System.out.println(kind);
            BookRepository.insertToDatabase(kind,id,tag,link);
        }
    }
}
