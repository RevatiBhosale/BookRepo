package com.example.BookProject.repository;

import com.example.BookProject.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

    @Autowired
    JdbcTemplate jdbcTemplate;

    public void insertToDatabase(String kind, String id, String tag, String link) {
        String sql = "INSERT INTO revati.book(kind,id,tag,link) VALUES(?,?,?,?)";
        Object params[] = new Object[] {kind,id,tag,link};
        jdbcTemplate.update(sql,params);
    }

}

